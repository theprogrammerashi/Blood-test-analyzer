from fastapi import FastAPI, File, UploadFile, Form, HTTPException
import os
import uuid
import fitz  # PyMuPDF
from crewai import Crew, Process, Task

from crew_setup import doctor, verifier, nutritionist, exercise_specialist

app = FastAPI(title="Blood Test Report Analyzer")

def extract_text_from_pdf(file_path: str) -> str:
    try:
        with fitz.open(file_path) as doc:
            text = ""
            for page in doc:
                text += page.get_text()
        return text.strip()
    except Exception as e:
        return f"Error reading PDF: {str(e)}"

def run_crew(query: str, report_text: str):
    """Run the crew to analyze the report"""

    # Dynamically create task
    analyze_task = Task(
        description=query,
        expected_output="A detailed summary of the report including medical, nutritional, and fitness suggestions.",
        context={
            "blood_report": report_text
        },
        agent=doctor  # Starting agent
    )

    crew = Crew(
        agents=[verifier, doctor, nutritionist, exercise_specialist],
        tasks=[analyze_task],
        process=Process.sequential,
        verbose=True
    )

    result = crew.kickoff()
    return result

@app.get("/")
async def root():
    return {"message": "Blood Test Report Analyzer API is running"}

@app.post("/analyze")
async def analyze_blood_report(
    file: UploadFile = File(...),
    query: str = Form(default="Summarize my Blood Test Report")
):
    file_id = str(uuid.uuid4())
    file_path = f"data/report_{file_id}.pdf"

    try:
        os.makedirs("data", exist_ok=True)

        # Save uploaded PDF
        with open(file_path, "wb") as f:
            content = await file.read()
            f.write(content)

        # Extract text from PDF
        report_text = extract_text_from_pdf(file_path)

        if not report_text:
            raise HTTPException(status_code=400, detail="Failed to extract content from the uploaded PDF.")

        # Run Crew with extracted text
        response = run_crew(query=query.strip(), report_text=report_text)

        return {
            "status": "success",
            "query": query,
            "analysis": response,
            "file_processed": file.filename
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error processing report: {str(e)}")

    finally:
        if os.path.exists(file_path):
            try:
                os.remove(file_path)
            except:
                pass
