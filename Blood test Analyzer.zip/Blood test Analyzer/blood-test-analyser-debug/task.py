# task.py

from crewai import Task
from crew_setup import doctor, verifier, nutritionist, exercise_specialist
from tools import BloodTestReportTool

# Initialize tool instance
blood_tool = BloodTestReportTool().read_data_tool

## Doctor Task: Analyze report for medical diagnosis
def medical_analysis_task(query: str, report_text: str):
    return Task(
        description=f"Analyze the patient's blood test data and provide a comprehensive medical summary. User asked: {query}",
        expected_output="Summary of potential diagnoses, any health risks, and recommendations for further medical action.",
        context={"query": query, "blood_report": report_text},
        agent=doctor,
        tools=[blood_tool],
        async_execution=False,
    )

## Verifier Task: Confirm the file is a blood test
def verification_task(report_text: str):
    return Task(
        description="Verify if the uploaded file content appears to be a valid blood test report.",
        expected_output="Clearly state if the content appears to be a real blood test. Mention any key terms or missing sections.",
        context={"blood_report": report_text},
        agent=verifier,
        tools=[blood_tool],
        async_execution=False
    )

## Nutritionist Task: Provide nutrition advice
def nutrition_analysis_task(query: str, report_text: str):
    return Task(
        description="Based on the blood test report, provide dietary recommendations to improve health.",
        expected_output="Suggestions for diet changes, supplementation if needed, and meal plans based on deficiencies.",
        context={"query": query, "blood_report": report_text},
        agent=nutritionist,
        tools=[blood_tool],
        async_execution=False,
    )

## Exercise Task: Suggest a workout plan
def exercise_planning_task(query: str, report_text: str):
    return Task(
        description="Use the report data to craft a personalized fitness or exercise plan.",
        expected_output="Weekly workout schedule with safe exercises based on medical insights from the blood test.",
        context={"query": query, "blood_report": report_text},
        agent=exercise_specialist,
        tools=[blood_tool],
        async_execution=False
    )
