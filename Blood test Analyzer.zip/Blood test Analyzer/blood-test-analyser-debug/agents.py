# crew_setup.py

import os
from dotenv import load_dotenv
load_dotenv()

# Load your LLM (example: OpenAI, change if using another provider)
from langchain.chat_models import ChatOpenAI

from crewai.agents import Agent
from tools import search_tool, BloodTestReportTool

# Load LLM
llm = ChatOpenAI(model_name="gpt-4", temperature=0.7)

# Shared tools
blood_test_tool = BloodTestReportTool().read_data_tool

# === Doctor Agent ===
doctor = Agent(
    role="Senior Medical Doctor",
    goal="Accurately interpret blood test reports and provide evidence-based medical advice.",
    verbose=True,
    backstory=(
        "A highly experienced physician known for diagnosing complex health issues using blood work and other lab tests. "
        "You are methodical, cautious, and prioritize patient safety."
    ),
    tools=[blood_test_tool],
    llm=llm,
    max_iter=3,
    max_rpm=1,
    allow_delegation=True
)

# === Verifier Agent ===
verifier = Agent(
    role="Medical Data Verifier",
    goal="Ensure uploaded reports are valid blood test data and confirm data accuracy before analysis.",
    verbose=True,
    backstory=(
        "A meticulous health data verifier with experience in reviewing lab reports for clinical use. "
        "You follow strict medical standards and never skip over details."
    ),
    tools=[blood_test_tool],
    llm=llm,
    max_iter=2,
    max_rpm=1,
    allow_delegation=False
)

# === Nutritionist Agent ===
nutritionist = Agent(
    role="Clinical Nutritionist",
    goal="Provide diet and nutrition guidance based on blood test values and general health markers.",
    verbose=True,
    backstory=(
        "A licensed clinical nutritionist focused on creating personalized dietary plans to improve health and well-being."
    ),
    tools=[blood_test_tool],
    llm=llm,
    max_iter=2,
    max_rpm=1,
    allow_delegation=False
)

# === Exercise Specialist Agent ===
exercise_specialist = Agent(
    role="Certified Fitness Coach",
    goal="Suggest exercise routines suitable for the user’s current health, based on blood test insights.",
    verbose=True,
    backstory=(
        "A certified exercise physiologist specializing in creating safe and effective workouts based on health data."
    ),
    tools=[blood_test_tool],
    llm=llm,
    max_iter=2,
    max_rpm=1,
    allow_delegation=False
)
