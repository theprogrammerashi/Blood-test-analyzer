# tools.py

import os
from langchain.document_loaders import PDFLoader
from crewai_tools import BaseTool
from crewai_tools.tools.serper_dev_tool import SerperDevTool

# Search Tool (Serper)
search_tool = SerperDevTool()

# Blood Report Reader Tool
class BloodTestReportTool:
    def __init__(self):
        self.read_data_tool = BaseTool(
            name="Blood Report Reader",
            description="Reads and returns text from a blood test PDF file",
            func=self.read_pdf_content
        )

    def read_pdf_content(self, path='data/sample.pdf') -> str:
        """Reads the blood test report from a PDF and returns cleaned text"""
        try:
            docs = PDFLoader(file_path=path).load()

            full_report = ""
            for data in docs:
                content = data.page_content.strip()
                content = content.replace("\n\n", "\n")
                full_report += content + "\n"

            return full_report.strip()
        except Exception as e:
            return f"Error reading PDF: {str(e)}"


# Nutrition Tool (future extension)
class NutritionTool:
    def __init__(self):
        self.analyze_nutrition_tool = BaseTool(
            name="Nutrition Analysis Tool",
            description="Analyzes blood report text and gives nutritional advice",
            func=self.analyze
        )

    def analyze(self, blood_report_data: str) -> str:
        # TODO: Add real nutrition logic
        return "Nutrition analysis coming soon."


# Exercise Tool (future extension)
class ExerciseTool:
    def __init__(self):
        self.create_exercise_plan_tool = BaseTool(
            name="Exercise Planning Tool",
            description="Suggests workouts based on blood test results",
            func=self.plan
        )

    def plan(self, blood_report_data: str) -> str:
        # TODO: Add real fitness logic
        return "Exercise planning coming soon."
